<aside id="sidebar">
	<?php dynamic_sidebar("Right Sidebar Widgets"); ?>
</aside>