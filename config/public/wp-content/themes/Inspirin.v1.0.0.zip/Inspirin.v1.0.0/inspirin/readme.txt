Please read our documentation before install the theme ( We included videos in that to help users can easily setup the theme ). If you have any questions or issues with the theme, please post it at the theme's topic: http://www.famethemes.com/themes/support/forum/premium-themes/inspirin/

Thanks!
http://www.famethemes.com