<aside id="sidebar-left">
	<?php dynamic_sidebar("Left Sidebar Widgets"); ?>
</aside>